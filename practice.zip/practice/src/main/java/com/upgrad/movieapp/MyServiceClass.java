package com.upgrad.movieapp;

import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

@Profile("qa")
@Component
public class MyServiceClass {
}
